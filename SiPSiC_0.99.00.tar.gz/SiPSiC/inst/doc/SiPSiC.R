## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----Example, warning=FALSE---------------------------------------------------
library(SiPSiC)
rowIndex <- colIndex <- matValues <- c(1:4)
geneCountsMatrix <- Matrix::sparseMatrix(i = rowIndex, j = colIndex, x = matValues)

## Make sure your matrix is indeed a sparse matrix (of type dgCMatrix)! 

rownames(geneCountsMatrix) <- c("Gene1", "Gene2", "Gene3", "Gene4")
colnames(geneCountsMatrix) <- c("Cell1", "Cell2", "Cell3", "Cell4")
pathwayGenesList <- c("Gene1", "Gene2", "Gene4")
scoresAndIndices <- getPathwayScores(geneCountsMatrix, pathwayGenesList)
pathwayScoresOfCells <- scoresAndIndices$pathwayScores
pathwayGeneIndices <- scoresAndIndices$index

## -----------------------------------------------------------------------------
sessionInfo()

